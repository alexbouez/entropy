#!/bin/bash
echo 524288 > /sys/kernel/tracing/buffer_size_kb 
